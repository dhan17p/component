sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("newchildcomponet.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);